package com.esgi.handiwe.BLL;


import com.esgi.handiwe.Model.Conversation;

/**
 * Created by Pico on 05/10/2016.
 */

public class ConversationManager {
}
