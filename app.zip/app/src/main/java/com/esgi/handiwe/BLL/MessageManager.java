package com.esgi.handiwe.BLL;

/**
 * Created by Pico on 05/10/2016.
 */

public class MessageManager {
}
