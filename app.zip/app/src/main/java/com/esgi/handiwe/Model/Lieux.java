package com.esgi.handiwe.Model;

/**
 * Created by Pico on 05/10/2016.
 */

public class Lieux {

    private int _id;




    //region GETTER
    //endregion

    //region SETTER
    //endregion

}
