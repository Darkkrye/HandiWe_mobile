package com.esgi.handiwe.Model;

/**
 * Created by Pico on 05/10/2016.
 */

public enum Jours {
    LUNDI,
    MARDI,
    MERCREDI,
    JEUDI,
    VENDREDI,
    SAMEDI,
    DIMANCHE;
}
