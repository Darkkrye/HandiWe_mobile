package com.esgi.handiwe.Model;

/**
 * Created by Pico on 05/10/2016.
 */

public class TypeHandicap {

    private int     _id;
    private String  _libelle;




    //region GETTER
    //endregion

    //region SETTER
    //endregion
}
