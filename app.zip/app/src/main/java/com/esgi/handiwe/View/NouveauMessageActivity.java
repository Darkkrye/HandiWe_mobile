package com.esgi.handiwe.View;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.esgi.handiwe.R;

public class NouveauMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nouveau_message);
    }
}
